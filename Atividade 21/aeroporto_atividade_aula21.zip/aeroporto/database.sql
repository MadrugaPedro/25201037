CREATE DATABASE IF NOT EXISTS aeroporto CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aeroporto;

CREATE TABLE IF NOT EXISTS voo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(20) NOT NULL,
    origem VARCHAR(100) NOT NULL,
    destino VARCHAR(100) NOT NULL,
    data_partida DATETIME NOT NULL
);

INSERT INTO voo (numero, origem, destino, data_partida) VALUES
('LA3450', 'Brasília (BSB)', 'São Paulo (CGH)', '2026-11-10 08:30:00'),
('G31422', 'Brasília (BSB)', 'Rio de Janeiro (SDU)', '2026-11-10 14:15:00');

EXIT;

<?php require __DIR__ . '/../../includes/header.php'; ?>

<h2>Editar Voo #<?= htmlspecialchars((string) $vooAtual['id']) ?></h2>

<form action="index.php?acao=atualizar" method="POST">
    <input type="hidden" name="id" value="<?= htmlspecialchars((string) $vooAtual['id']) ?>">

    <div class="form-group">
        <label for="numero">Número do Voo:</label>
        <input type="text" id="numero" name="numero"
               value="<?= htmlspecialchars($vooAtual['numero']) ?>" required>
    </div>

    <div class="form-group">
        <label for="origem">Origem:</label>
        <input type="text" id="origem" name="origem"
               value="<?= htmlspecialchars($vooAtual['origem']) ?>" required>
    </div>

    <div class="form-group">
        <label for="destino">Destino:</label>
        <input type="text" id="destino" name="destino"
               value="<?= htmlspecialchars($vooAtual['destino']) ?>" required>
    </div>

    <div class="form-group">
        <label for="data_partida">Data e Hora de Partida:</label>
        <input type="datetime-local" id="data_partida" name="data_partida"
               value="<?= htmlspecialchars(date('Y-m-d\TH:i', strtotime($vooAtual['data_partida']))) ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Atualizar Voo</button>
    <a href="index.php?acao=listar" class="btn btn-secondary">Cancelar</a>
</form>

<?php require __DIR__ . '/../../includes/footer.php'; ?>

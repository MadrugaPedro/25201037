<?php require __DIR__ . '/../../includes/header.php'; ?>

<?php if ($erro === 'fk'): ?>
    <div class="alert-danger">
        Não foi possível excluir este voo pois existem registros vinculados a ele (ex: passagens ou tripulação).
    </div>
<?php endif; ?>

<p>
    <a href="index.php?acao=criar" class="btn btn-primary">+ Cadastrar Novo Voo</a>
</p>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Número</th>
            <th>Origem</th>
            <th>Destino</th>
            <th>Partida</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($voos)): ?>
            <tr>
                <td colspan="6">Nenhum voo cadastrado.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($voos as $v): ?>
                <tr>
                    <td><?= htmlspecialchars((string) $v['id']) ?></td>
                    <td><?= htmlspecialchars($v['numero']) ?></td>
                    <td><?= htmlspecialchars($v['origem']) ?></td>
                    <td><?= htmlspecialchars($v['destino']) ?></td>
                    <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($v['data_partida']))) ?></td>
                    <td>
                        <a href="index.php?acao=editar&id=<?= htmlspecialchars((string) $v['id']) ?>" class="btn btn-warning">Editar</a>
                        <a href="index.php?acao=excluir&id=<?= htmlspecialchars((string) $v['id']) ?>"
                           class="btn btn-danger"
                           onclick="return confirm('Tem certeza que deseja excluir este voo?')">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../../includes/footer.php'; ?>

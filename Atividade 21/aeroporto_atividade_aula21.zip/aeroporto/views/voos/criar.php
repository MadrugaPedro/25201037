<?php require __DIR__ . '/../../includes/header.php'; ?>

<h2>Cadastrar Novo Voo</h2>

<form action="index.php?acao=salvar" method="POST">
    <div class="form-group">
        <label for="numero">Número do Voo:</label>
        <input type="text" id="numero" name="numero" placeholder="Ex: LA3450" required>
    </div>

    <div class="form-group">
        <label for="origem">Origem:</label>
        <input type="text" id="origem" name="origem" placeholder="Ex: Brasília (BSB)" required>
    </div>

    <div class="form-group">
        <label for="destino">Destino:</label>
        <input type="text" id="destino" name="destino" placeholder="Ex: São Paulo (GRU)" required>
    </div>

    <div class="form-group">
        <label for="data_partida">Data e Hora de Partida:</label>
        <input type="datetime-local" id="data_partida" name="data_partida" required>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Voo</button>
    <a href="index.php?acao=listar" class="btn btn-secondary">Cancelar</a>
</form>

<?php require __DIR__ . '/../../includes/footer.php'; ?>

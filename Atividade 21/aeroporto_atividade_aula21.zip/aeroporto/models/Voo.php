<?php

require_once __DIR__ . '/../config/database.php';

class Voo
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::conectar();
    }

    // LISTAR TODOS OS VOOS
    public function listar(): array
    {
        $sql = "SELECT * FROM voo ORDER BY data_partida ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // BUSCAR UM VOO PELO ID
    public function buscar(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM voo WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $voo = $stmt->fetch();

        return $voo ?: null;
    }

    // CRIAR NOVO VOO
    public function criar(array $dados): bool
    {
        $sql = "INSERT INTO voo (numero, origem, destino, data_partida)
                VALUES (:numero, :origem, :destino, :data_partida)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':numero'       => trim($dados['numero']),
            ':origem'       => trim($dados['origem']),
            ':destino'      => trim($dados['destino']),
            ':data_partida' => $dados['data_partida'],
        ]);
    }

    // EDITAR VOO EXISTENTE
    public function editar(int $id, array $dados): bool
    {
        $sql = "UPDATE voo
                SET numero = :numero,
                    origem = :origem,
                    destino = :destino,
                    data_partida = :data_partida
                WHERE id = :id";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':numero'       => trim($dados['numero']),
            ':origem'       => trim($dados['origem']),
            ':destino'      => trim($dados['destino']),
            ':data_partida' => $dados['data_partida'],
            ':id'           => $id,
        ]);
    }

    // EXCLUIR VOO (Com tratamento para Foreign Keys)
    public function excluir(int $id): bool
    {
        try {
            $stmt = $this->db->prepare("DELETE FROM voo WHERE id = :id");
            return $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            // Caso o voo possua passagens/aeronaves/portões vinculados (Erro 23000 - Integrity constraint violation)
            return false;
        }
    }
}

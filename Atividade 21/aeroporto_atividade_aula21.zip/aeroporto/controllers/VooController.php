<?php

require_once __DIR__ . '/../models/Voo.php';

class VooController
{
    private Voo $voo;

    public function __construct()
    {
        $this->voo = new Voo();
    }

    // Exibe a listagem
    public function listar(): void
    {
        $voos = $this->voo->listar();
        $erro = $_GET['erro'] ?? null;
        require __DIR__ . '/../views/voos/listar.php';
    }

    // Exibe o formulário de cadastro
    public function criar(): void
    {
        require __DIR__ . '/../views/voos/criar.php';
    }

    // Recebe o POST do cadastro
    public function salvar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->voo->criar($_POST);
        }
        header('Location: index.php?acao=listar');
        exit;
    }

    // Exibe o formulário de edição
    public function editar(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $vooAtual = $this->voo->buscar($id);

        if (!$vooAtual) {
            header('Location: index.php?acao=listar');
            exit;
        }

        require __DIR__ . '/../views/voos/editar.php';
    }

    // Recebe o POST da edição
    public function atualizar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int) ($_POST['id'] ?? 0);
            $this->voo->editar($id, $_POST);
        }
        header('Location: index.php?acao=listar');
        exit;
    }

    // Remove um registro
    public function excluir(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $sucesso = $this->voo->excluir($id);

        if (!$sucesso) {
            header('Location: index.php?acao=listar&erro=fk');
            exit;
        }

        header('Location: index.php?acao=listar');
        exit;
    }
}

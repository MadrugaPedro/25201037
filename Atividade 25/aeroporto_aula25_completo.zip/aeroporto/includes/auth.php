<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$acaoAtual = $_GET['acao'] ?? '';

// Rotas públicas que NÃO precisam de autenticação
$rotasPublicas = ['login', 'logar'];

if (empty($_SESSION['usuario_id']) && !in_array($acaoAtual, $rotasPublicas, true)) {
    header('Location: index.php?acao=login');
    exit;
}

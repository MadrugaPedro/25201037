CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil VARCHAR(20) NOT NULL DEFAULT 'operador'
);
INSERT INTO usuarios (email, senha_hash, perfil) 
VALUES ('admin@aeroporto.com', '$2y$10$tZ2E7/4L06U./uH/7j8B.OoT9C8vjB4X8C/6O6/8nC/T7.m8h.O6C', 'admin');

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../controllers/VooController.php';
require_once __DIR__ . '/../controllers/AuthController.php';

$vooController = new VooController();
$authController = new AuthController();

$acao = $_GET['acao'] ?? 'listar';

match ($acao) {
    'login'     => $authController->telaLogin(),
    'logar'     => $authController->logar(),
    'logout'    => $authController->logout(),
    'criar'     => $vooController->criar(),
    'salvar'    => $vooController->salvar(),
    'editar'    => $vooController->editar(),
    'atualizar' => $vooController->atualizar(),
    'excluir'   => $vooController->excluir(),
    'lixeira'   => $vooController->lixeira(),
    'restaurar' => $vooController->restaurar(),
    default     => $vooController->listar(),
};

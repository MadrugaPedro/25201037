<?php
require_once __DIR__ . '/../config/database.php';

class AuthController
{
    public function telaLogin(): void
    {
        // Se já estiver logado, manda direto pra listagem
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!empty($_SESSION['usuario_id'])) {
            header('Location: index.php?acao=listar');
            exit;
        }

        require __DIR__ . '/../views/auth/login.php';
    }

    public function logar(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $senha = $_POST['senha'] ?? '';

            $db = Database::conectar();
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email");
            $stmt->execute([':email' => $email]);
            $usuario = $stmt->fetch();

            if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
                session_regenerate_id(true);
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['perfil'] = $usuario['perfil'];
                header('Location: index.php?acao=listar');
                exit;
            }

            header('Location: index.php?acao=login&erro=1');
            exit;
        }
    }

    public function logout(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION = [];
        session_destroy();
        header('Location: index.php?acao=login');
        exit;
    }
}

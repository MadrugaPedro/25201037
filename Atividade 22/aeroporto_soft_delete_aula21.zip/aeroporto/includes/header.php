<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Aeroporto - Gestão de Voos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; background-color: #f8f9fa; color: #333; }
        .container { max-width: 950px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h1 { margin-top: 0; color: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #dee2e6; padding: 10px 12px; text-align: left; }
        th { background-color: #0056b3; color: #fff; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .btn { display: inline-block; padding: 8px 14px; text-decoration: none; border-radius: 4px; font-size: 14px; cursor: pointer; border: none; }
        .btn-primary { background-color: #0056b3; color: #fff; }
        .btn-warning { background-color: #ffc107; color: #212529; }
        .btn-danger { background-color: #dc3545; color: #fff; }
        .btn-secondary { background-color: #6c757d; color: #fff; }
        .btn-success { background-color: #198754; color: #fff; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input[type="text"], input[type="datetime-local"] { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .alert { padding: 12px; border-radius: 4px; margin-bottom: 15px; }
        .alert-success { background-color: #d1e7dd; color: #0f5132; border: 1px solid #badbcc; }
        .alert-danger { background-color: #f8d7da; color: #842029; border: 1px solid #f5c2c7; }
        .nav-bar { margin-bottom: 20px; display: flex; gap: 10px; }
    </style>
</head>
<body>
<div class="container">
    <h1>Controle de Aeroporto - Voos</h1>
    <div class="nav-bar">
        <a href="index.php?acao=listar" class="btn btn-secondary">Voos Ativos</a>
        <a href="index.php?acao=lixeira" class="btn btn-secondary">Voos Excluídos (Lixeira)</a>
    </div>
    <hr>

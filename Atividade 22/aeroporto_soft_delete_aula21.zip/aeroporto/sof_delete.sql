USE aeroporto;

1. Migration: Adiciona a coluna deleted_at e indexa para performance
ALTER TABLE voo 
  ADD COLUMN deleted_at DATETIME NULL DEFAULT NULL,
  ADD INDEX idx_voo_deleted_at (deleted_at);

2. Tabela de Auditoria com suporte a JSON
CREATE TABLE IF NOT EXISTS auditoria (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  tabela      VARCHAR(50) NOT NULL,
  registro_id INT NOT NULL,
  acao        VARCHAR(20) NOT NULL,
  usuario_id  INT NULL,
  dados_antes JSON NULL,
  criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Conceder permissões para a conta da aplicação se estiver usando app_aeroporto:
GRANT SELECT, INSERT ON aeroporto.auditoria TO 'app_aeroporto'@'localhost';

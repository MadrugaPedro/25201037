<?php

require_once __DIR__ . '/../config/database.php';

class Voo
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::conectar();
    }

    // LISTAR SOMENTE ATIVOS
    public function listar(): array
    {
        $sql = "SELECT * FROM voo WHERE deleted_at IS NULL ORDER BY data_partida ASC";
        return $this->db->query($sql)->fetchAll();
    }

    // LISTAR SOMENTE EXCLUÍDOS (Lixeira / Soft Deleted)
    public function listarExcluidos(): array
    {
        $sql = "SELECT * FROM voo WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC";
        return $this->db->query($sql)->fetchAll();
    }

    // BUSCAR UM REGISTRO ATIVO (para edição e detalhe)
    public function buscar(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM voo WHERE id = :id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id]);
        $voo = $stmt->fetch();

        return $voo ?: null;
    }

    // CRIAR VOO
    public function criar(array $dados): bool
    {
        $sql = "INSERT INTO voo (numero, origem, destino, data_partida)
                VALUES (:numero, :origem, :destino, :data_partida)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':numero'       => trim($dados['numero']),
            ':origem'       => trim($dados['origem']),
            ':destino'      => trim($dados['destino']),
            ':data_partida' => $dados['data_partida'],
        ]);
    }

    // EDITAR VOO (apenas se estiver ativo)
    public function editar(int $id, array $dados): bool
    {
        $sql = "UPDATE voo
                SET numero = :numero,
                    origem = :origem,
                    destino = :destino,
                    data_partida = :data_partida
                WHERE id = :id AND deleted_at IS NULL";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':numero'       => trim($dados['numero']),
            ':origem'       => trim($dados['origem']),
            ':destino'      => trim($dados['destino']),
            ':data_partida' => $dados['data_partida'],
            ':id'           => $id,
        ]);
    }

    // SOFT DELETE COM AUDITORIA ATÔMICA (TRANSAÇÃO)
    public function excluir(int $id, int $usuarioId = 1): bool
    {
        try {
            $this->db->beginTransaction();

            // 1. Busca os dados atuais antes de marcar como excluído
            $stmtBusca = $this->db->prepare("SELECT * FROM voo WHERE id = :id AND deleted_at IS NULL FOR UPDATE");
            $stmtBusca->execute([':id' => $id]);
            $vooAtual = $stmtBusca->fetch();

            if (!$vooAtual) {
                $this->db->rollBack();
                return false; // Registro não existe ou já foi excluído
            }

            // 2. Executa o Soft Delete via UPDATE
            $stmtUpdate = $this->db->prepare("UPDATE voo SET deleted_at = NOW() WHERE id = :id");
            $stmtUpdate->execute([':id' => $id]);

            // 3. Registra na tabela de auditoria (com payload JSON do estado anterior)
            $stmtAudit = $this->db->prepare(
                "INSERT INTO auditoria (tabela, registro_id, acao, usuario_id, dados_antes)
                 VALUES (:tabela, :registro_id, :acao, :usuario_id, :dados_antes)"
            );
            $stmtAudit->execute([
                ':tabela'      => 'voo',
                ':registro_id' => $id,
                ':acao'        => 'SOFT_DELETE',
                ':usuario_id'  => $usuarioId,
                ':dados_antes' => json_encode($vooAtual, JSON_UNESCAPED_UNICODE),
            ]);

            // Se tudo deu certo, efetiva as duas operações juntas
            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            // Em caso de qualquer falha na auditoria ou no update, desfaz tudo
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            error_log("Erro no Soft Delete: " . $e->getMessage());
            return false;
        }
    }

    // RESTAURAR VOO
    public function restaurar(int $id, int $usuarioId = 1): bool
    {
        try {
            $this->db->beginTransaction();

            $stmtUpdate = $this->db->prepare("UPDATE voo SET deleted_at = NULL WHERE id = :id AND deleted_at IS NOT NULL");
            $stmtUpdate->execute([':id' => $id]);

            // Registra a restauração na auditoria
            $stmtAudit = $this->db->prepare(
                "INSERT INTO auditoria (tabela, registro_id, acao, usuario_id, dados_antes)
                 VALUES (:tabela, :registro_id, :acao, :usuario_id, :dados_antes)"
            );
            $stmtAudit->execute([
                ':tabela'      => 'voo',
                ':registro_id' => $id,
                ':acao'        => 'RESTORE',
                ':usuario_id'  => $usuarioId,
                ':dados_antes' => null,
            ]);

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            error_log("Erro na Restauração: " . $e->getMessage());
            return false;
        }
    }
}

<?php

require_once __DIR__ . '/../models/Voo.php';

class VooController
{
    private Voo $voo;

    public function __construct()
    {
        $this->voo = new Voo();
    }

    // Listar voos ativos
    public function listar(): void
    {
        $voos = $this->voo->listar();
        $mensagem = $_GET['msg'] ?? null;
        $tipoMensagem = $_GET['tipo'] ?? 'success';
        require __DIR__ . '/../views/voos/listar.php';
    }

    // Tela de voos excluídos (Lixeira)
    public function lixeira(): void
    {
        $voosExcluidos = $this->voo->listarExcluidos();
        $mensagem = $_GET['msg'] ?? null;
        $tipoMensagem = $_GET['tipo'] ?? 'success';
        require __DIR__ . '/../views/voos/lixeira.php';
    }

    public function criar(): void
    {
        require __DIR__ . '/../views/voos/criar.php';
    }

    public function salvar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->voo->criar($_POST);
        }
        header('Location: index.php?acao=listar&msg=Voo cadastrado com sucesso!&tipo=success');
        exit;
    }

    public function editar(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $vooAtual = $this->voo->buscar($id);

        if (!$vooAtual) {
            header('Location: index.php?acao=listar&msg=Voo não encontrado ou inativo.&tipo=danger');
            exit;
        }

        require __DIR__ . '/../views/voos/editar.php';
    }

    public function atualizar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int) ($_POST['id'] ?? 0);
            $this->voo->editar($id, $_POST);
        }
        header('Location: index.php?acao=listar&msg=Voo atualizado com sucesso!&tipo=success');
        exit;
    }

    // Exclusão com confirmação e Soft Delete
    public function excluir(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $sucesso = $this->voo->excluir($id);

        if ($sucesso) {
            header('Location: index.php?acao=listar&msg=Voo movido para a lixeira com sucesso!&tipo=success');
        } else {
            header('Location: index.php?acao=listar&msg=Falha ao excluir o voo.&tipo=danger');
        }
        exit;
    }

    // Restauração de voo excluído
    public function restaurar(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $sucesso = $this->voo->restaurar($id);

        if ($sucesso) {
            header('Location: index.php?acao=lixeira&msg=Voo restaurado com sucesso!&tipo=success');
        } else {
            header('Location: index.php?acao=lixeira&msg=Falha ao restaurar o voo.&tipo=danger');
        }
        exit;
    }
}

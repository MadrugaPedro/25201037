<?php

require_once __DIR__ . '/../controllers/VooController.php';

$controller = new VooController();
$acao = $_GET['acao'] ?? 'listar';

match ($acao) {
    'criar'     => $controller->criar(),
    'salvar'    => $controller->salvar(),
    'editar'    => $controller->editar(),
    'atualizar' => $controller->atualizar(),
    'excluir'   => $controller->excluir(),
    'lixeira'   => $controller->lixeira(),
    'restaurar' => $controller->restaurar(),
    default     => $controller->listar(),
};

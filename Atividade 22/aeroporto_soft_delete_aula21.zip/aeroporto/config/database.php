<?php

class Database
{
    private static ?PDO $conexao = null;

    public static function conectar(): PDO
    {
        if (self::$conexao === null) {
            $host    = 'localhost';
            $banco   = 'aeroporto';
            $usuario = 'app_aeroporto';
            $senha   = 'SenhaForte#123'; // Se você usou 'senha123', coloque 'senha123' aqui!

            self::$conexao = new PDO(
                "mysql:host=$host;dbname=$banco;charset=utf8mb4",
                $usuario,
                $senha,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        }

        return self::$conexao;
    }
}

<?php require __DIR__ . '/../../includes/header.php'; ?>

<h2>Voos Excluídos (Soft Delete)</h2>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?= htmlspecialchars($tipoMensagem) ?>">
        <?= htmlspecialchars($mensagem) ?>
    </div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Número</th>
            <th>Origem</th>
            <th>Destino</th>
            <th>Data de Exclusão</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($voosExcluidos)): ?>
            <tr>
                <td colspan="6">A lixeira está vazia. Nenhum registro excluído.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($voosExcluidos as $v): ?>
                <tr>
                    <td><?= htmlspecialchars((string) $v['id']) ?></td>
                    <td><?= htmlspecialchars($v['numero']) ?></td>
                    <td><?= htmlspecialchars($v['origem']) ?></td>
                    <td><?= htmlspecialchars($v['destino']) ?></td>
                    <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($v['deleted_at']))) ?></td>
                    <td>
                        <a href="index.php?acao=restaurar&id=<?= htmlspecialchars((string) $v['id']) ?>"
                           class="btn btn-success"
                           onclick="return confirm('Deseja realmente restaurar este voo para a listagem principal?')">Restaurar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
